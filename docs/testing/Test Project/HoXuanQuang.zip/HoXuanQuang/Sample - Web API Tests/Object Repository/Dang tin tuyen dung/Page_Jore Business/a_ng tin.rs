<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_ng tin</name>
   <tag></tag>
   <elementGuidId>124e2f68-9d61-4b4d-a59a-e15aef1c712e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//a[@id='post_news_recruit']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#post_news_recruit</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
      <webElementGuid>b0f23adf-5cb0-4fa2-b3a9-5ac17962ce7f</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>post_news_recruit</value>
      <webElementGuid>33fa2c6d-ad19-4e30-a555-806ecbb9a594</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>/employer/add_recruitment</value>
      <webElementGuid>4027ed63-b109-4a84-8bc4-f1376f3a1f7d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Đăng tin
                
            </value>
      <webElementGuid>f7c2b3e1-a8dc-48a8-8903-dbbb5904e48d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;post_news_recruit&quot;)</value>
      <webElementGuid>7fea99be-8259-48ca-b313-b6cde8c9d242</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//a[@id='post_news_recruit']</value>
      <webElementGuid>0bf931b5-be43-4ab2-9fa6-63fd68f587e1</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:link</name>
      <type>Main</type>
      <value>//a[contains(text(),'Đăng tin')]</value>
      <webElementGuid>616ec191-7a98-4e26-a793-6408c4907274</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Trang cá nhân'])[1]/preceding::a[2]</value>
      <webElementGuid>860a0cd3-433b-49c1-bf63-d64cacff35cf</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Quản lý tin tuyển dụng'])[1]/preceding::a[3]</value>
      <webElementGuid>27f13303-8d6e-4cdf-851d-98f1396722f0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Đăng tin']/parent::*</value>
      <webElementGuid>0172dc5a-6565-48a2-befa-5e30864d1c94</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:href</name>
      <type>Main</type>
      <value>//a[contains(@href, '/employer/add_recruitment')]</value>
      <webElementGuid>51c16385-98e8-4343-b663-090081d281c3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//a[2]</value>
      <webElementGuid>8bae128d-0a38-4306-9a02-8dd8b6d8a617</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//a[@id = 'post_news_recruit' and @href = '/employer/add_recruitment' and (text() = 'Đăng tin
                
            ' or . = 'Đăng tin
                
            ')]</value>
      <webElementGuid>32d15c77-82d9-4a60-8252-adb8826de593</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
