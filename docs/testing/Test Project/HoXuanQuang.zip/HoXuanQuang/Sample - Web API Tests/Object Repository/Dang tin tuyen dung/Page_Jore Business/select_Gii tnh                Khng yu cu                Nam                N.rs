<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Gii tnh                Khng yu cu                Nam                N</name>
   <tag></tag>
   <elementGuidId>14e6412c-65a7-4be5-8792-8dcee5b5f72c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='sex_edit_news']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#sex_edit_news</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>e5d466bf-b3f5-4bfd-b3c3-c45a14018b5d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>sex_recruitment</value>
      <webElementGuid>9ed0e7d6-5f80-4553-919e-151501b81c50</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>sex_edit_news</value>
      <webElementGuid>ef80e7c6-c414-47f9-aa16-5c6fdc43486c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                Giới tính
                Không yêu cầu
                Nam
                Nữ
            </value>
      <webElementGuid>8508c26a-a07c-4993-84e6-62268c59de21</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;sex_edit_news&quot;)</value>
      <webElementGuid>936b2cce-506c-4bfe-bab6-543a916243c5</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='sex_edit_news']</value>
      <webElementGuid>1a8d9507-fb5d-4f6a-92a6-f5683f1921cc</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content_edit_news_home_recruit']/form/select[2]</value>
      <webElementGuid>982a17c9-b9f8-4956-9954-d29e3c65ccd2</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Giới tính'])[1]/following::select[1]</value>
      <webElementGuid>109a337f-ef9c-4b6b-81df-e3219b1fb729</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hình thức làm việc'])[1]/following::select[2]</value>
      <webElementGuid>fa486af4-260a-448d-ae45-081060bbf9ce</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kinh nghiệm'])[1]/preceding::select[1]</value>
      <webElementGuid>4cde4765-bbd2-483e-840c-c9f3edfa8771</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hạn nộp hồ sơ'])[1]/preceding::select[2]</value>
      <webElementGuid>239f7afe-7207-4ae0-9390-fcef6a91bd57</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select[2]</value>
      <webElementGuid>8b5bfb81-33aa-4e45-bef0-4aa030583826</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'sex_recruitment' and @id = 'sex_edit_news' and (text() = '
                Giới tính
                Không yêu cầu
                Nam
                Nữ
            ' or . = '
                Giới tính
                Không yêu cầu
                Nam
                Nữ
            ')]</value>
      <webElementGuid>222f0342-ecf0-4ee6-8679-aef75daa2993</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
