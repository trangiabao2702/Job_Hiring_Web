<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Kinh nghim                Khng yu cu                It nht 1 nm                It nht 2 nm                It nht 3 nm</name>
   <tag></tag>
   <elementGuidId>1195503b-ca4c-4096-8f6e-b38d53300b4c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='experience_edit_news']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#experience_edit_news</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>e900b6e4-0601-4513-a46c-796de72cbec9</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>experience_recruitment</value>
      <webElementGuid>b420508d-6577-4bbe-a1b4-037c27e58d30</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>experience_edit_news</value>
      <webElementGuid>9f05047c-1330-4151-95a1-2492da071076</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                Kinh nghiệm
                Không yêu cầu
                Ít nhất 1 năm
                Ít nhất 2 năm
                Ít nhất 3 năm
            </value>
      <webElementGuid>42822742-14ee-4b05-89dd-e1ea6094d117</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;experience_edit_news&quot;)</value>
      <webElementGuid>bd50ab2b-cc43-474b-a3cc-88f2858e95b6</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='experience_edit_news']</value>
      <webElementGuid>4e6df637-e4dd-40d9-8188-890dc7a6d725</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content_edit_news_home_recruit']/form/select[3]</value>
      <webElementGuid>891b391b-ca7c-43fa-ae4c-c56361cc462f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kinh nghiệm'])[1]/following::select[1]</value>
      <webElementGuid>66c4ef95-06f9-49c7-8779-23a06772406b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Giới tính'])[1]/following::select[2]</value>
      <webElementGuid>d7b31c64-9a0e-4cb4-82cc-f9dad5fcd4ac</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hạn nộp hồ sơ'])[1]/preceding::select[1]</value>
      <webElementGuid>7a7c5d68-7c46-4c46-add6-0a104fca1f9e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Địa điểm làm việc'])[1]/preceding::select[1]</value>
      <webElementGuid>21aa91f0-27f2-4b2b-912e-c0c9a420e183</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select[3]</value>
      <webElementGuid>5bb9ebc9-f38e-44fe-9014-27aa3ed19d21</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'experience_recruitment' and @id = 'experience_edit_news' and (text() = '
                Kinh nghiệm
                Không yêu cầu
                Ít nhất 1 năm
                Ít nhất 2 năm
                Ít nhất 3 năm
            ' or . = '
                Kinh nghiệm
                Không yêu cầu
                Ít nhất 1 năm
                Ít nhất 2 năm
                Ít nhất 3 năm
            ')]</value>
      <webElementGuid>a71487dc-98d9-4f52-93d0-fa174efcc3a9</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
