<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Hnh thc lm vic                Full Time                Part Time                Remote</name>
   <tag></tag>
   <elementGuidId>85633cb5-ab3d-4564-bdb7-d665adfdb067</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='method_work_edit_news']</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#method_work_edit_news</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>ed91cf43-bdb7-4a18-9744-04dfc25efda2</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>method_work_recruitment</value>
      <webElementGuid>48e595b2-87cd-4696-a973-c09f88ef7ee8</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>method_work_edit_news</value>
      <webElementGuid>3df45ad1-49fc-46b9-83f1-3afec631256c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                Hình thức làm việc
                Full Time
                Part Time
                Remote
            </value>
      <webElementGuid>e0c66724-1410-4d5c-8ae5-63e30239946c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;method_work_edit_news&quot;)</value>
      <webElementGuid>e8a009c6-7f13-4ec9-b9ea-2560917f91cc</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='method_work_edit_news']</value>
      <webElementGuid>49e3803b-8578-4d69-94dd-f147a2759485</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='content_edit_news_home_recruit']/form/select</value>
      <webElementGuid>cb076704-c34c-4e46-84aa-cb9405c2ed1f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Hình thức làm việc'])[1]/following::select[1]</value>
      <webElementGuid>5cd3f620-42bb-4826-bf59-7b1b79505b4b</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Số lượng'])[1]/following::select[1]</value>
      <webElementGuid>c3da632a-cb57-449f-9cee-0d1860d21771</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Giới tính'])[1]/preceding::select[1]</value>
      <webElementGuid>bf8c2164-451b-48b2-af26-485e684a8655</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Kinh nghiệm'])[1]/preceding::select[2]</value>
      <webElementGuid>ec912f61-1432-4c82-8e08-e963f3636337</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select</value>
      <webElementGuid>9a31d837-4f69-4830-b5a6-60f04f5490ed</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'method_work_recruitment' and @id = 'method_work_edit_news' and (text() = '
                Hình thức làm việc
                Full Time
                Part Time
                Remote
            ' or . = '
                Hình thức làm việc
                Full Time
                Part Time
                Remote
            ')]</value>
      <webElementGuid>19043edf-86d4-4612-871f-64111515caab</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
