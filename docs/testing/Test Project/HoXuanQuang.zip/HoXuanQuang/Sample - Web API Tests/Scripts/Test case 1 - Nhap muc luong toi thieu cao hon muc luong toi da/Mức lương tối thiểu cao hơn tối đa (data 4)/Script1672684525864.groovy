import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('https://employers-jore.onrender.com/')

WebUI.setText(findTestObject('Dang tin tuyen dung/Page_Jore Business/input_Email_email'), 'test_admin@gmail.com')

WebUI.setText(findTestObject('Dang tin tuyen dung/Page_Jore Business/input_Mt khu_password'), '1')

WebUI.click(findTestObject('Dang tin tuyen dung/Page_Jore Business/button_ng nhp'))

WebUI.click(findTestObject('Dang tin tuyen dung/Page_Jore Business/a_ng tin'))

WebUI.setText(findTestObject('Dang tin tuyen dung/Page_Jore Business/input_Tiu_title_recruitment'), 'VNG Games')

WebUI.setText(findTestObject('Dang tin tuyen dung/Page_Jore Business/input_Mc lng_min_salary_recruitment'), '1', FailureHandling.STOP_ON_FAILURE)

WebUI.setText(findTestObject('Dang tin tuyen dung/Page_Jore Business/input_Mc lng_max_salary_recruitment'), '0')

WebUI.setText(findTestObject('Dang tin tuyen dung/Page_Jore Business/input_S lng_quantity_recruitment'), '2')

WebUI.selectOptionByValue(findTestObject('Dang tin tuyen dung/Page_Jore Business/select_Hnh thc lm vic                Full Time                Part Time                Remote'), 
    'Full Time', false)

WebUI.selectOptionByValue(findTestObject('Dang tin tuyen dung/Page_Jore Business/select_Gii tnh                Khng yu cu                Nam                N'), 
    'Nam', false)

WebUI.selectOptionByValue(findTestObject('Dang tin tuyen dung/Page_Jore Business/select_Kinh nghim                Khng yu cu                It nht 1 nm                It nht 2 nm                It nht 3 nm'), 
    '1 năm', false)

WebUI.setText(findTestObject('Dang tin tuyen dung/Page_Jore Business/input_Hn np h s_deadline_submit_record_recruitment'), 
    '12/31/2022')

WebUI.setText(findTestObject('Dang tin tuyen dung/Page_Jore Business/input_a im lm vic_word_location_recruitment'), 'Linh Trung, Thủ Đức, Hồ Chí Minh')

WebUI.setText(findTestObject('Dang tin tuyen dung/Page_Jore Business/textarea_M t cng vic_job_describe_recruitment'), 'Front-End')

WebUI.setText(findTestObject('Dang tin tuyen dung/Page_Jore Business/textarea_Yu cu ng vin_require_candidate_recruitment'), 
    'biết Python')

WebUI.setText(findTestObject('Dang tin tuyen dung/Page_Jore Business/textarea_Quyn li_benefit_recruitment'), 'lương cao')

WebUI.click(findTestObject('Dang tin tuyen dung/Page_Jore Business/input_Quyn li_submit_edit_news'))

WebUI.verifyTextPresent('Mức lương không phù hợp', false)

WebUI.closeBrowser()

