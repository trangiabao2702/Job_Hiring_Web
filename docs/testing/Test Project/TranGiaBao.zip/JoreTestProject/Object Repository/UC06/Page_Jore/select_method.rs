<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_method</name>
   <tag></tag>
   <elementGuidId>7818683f-2f4c-4202-a862-b0ebc8720be5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#select_method_work_candidate</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='select_method_work_candidate']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>2c071901-9d2f-433d-9ae5-99c6159a0d44</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>select_method_work</value>
      <webElementGuid>415baa5e-4547-49d2-a918-97c270341468</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>select_method_work_candidate</value>
      <webElementGuid>c7071d4e-704b-44d5-829b-3a4763cb3d31</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    Full Time
    Part Time
    Remote
    Hình thức làm việc
  </value>
      <webElementGuid>451d7652-b2f3-4d9d-ad41-5e8b60abeb28</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;select_method_work_candidate&quot;)</value>
      <webElementGuid>2efb45d8-b9a9-406c-8ba5-071bac3c6b55</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='select_method_work_candidate']</value>
      <webElementGuid>c0244a25-a7ca-4282-9614-0ff74724777e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dành cho nhà tuyển dụng'])[1]/following::select[2]</value>
      <webElementGuid>8c1fc5be-b040-41e2-9dde-364d306f44f9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Đăng ký'])[1]/following::select[2]</value>
      <webElementGuid>c2a24a6b-1b2a-47cd-a7bf-7091e9af5946</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tìm kiếm'])[1]/preceding::select[3]</value>
      <webElementGuid>9ba254fc-ce2c-4dad-a4cc-267b1564876a</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Top công việc được quan tâm nhất'])[1]/preceding::select[3]</value>
      <webElementGuid>0f225eac-0f86-4c4a-b128-3d2f71f6639d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select[2]</value>
      <webElementGuid>72e3f45a-c4ab-4499-b64d-253083bab9d5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'select_method_work' and @id = 'select_method_work_candidate' and (text() = '
    Full Time
    Part Time
    Remote
    Hình thức làm việc
  ' or . = '
    Full Time
    Part Time
    Remote
    Hình thức làm việc
  ')]</value>
      <webElementGuid>c7362940-e243-46d7-8ca9-65347ed3d4f3</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
