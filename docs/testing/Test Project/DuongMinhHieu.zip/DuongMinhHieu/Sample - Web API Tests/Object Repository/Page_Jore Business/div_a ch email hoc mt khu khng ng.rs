<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_a ch email hoc mt khu khng ng</name>
   <tag></tag>
   <elementGuidId>7ecb14b6-1ff3-4b07-bb5a-4db60f2d6467</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>div.alert.alert-danger.mt-2</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//div[@id='rectangle_form_login']/form/div</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
      <webElementGuid>f500ecac-5ba8-4e32-b6b6-cbfb4414be2d</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>alert alert-danger mt-2</value>
      <webElementGuid>ada98922-f9b1-45fa-a2e4-ed9e62d28cb7</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                Địa chỉ email hoặc mật khẩu không đúng!
            </value>
      <webElementGuid>a00ace2a-7629-47c2-94c3-66936d3800cc</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rectangle_form_login&quot;)/form[1]/div[@class=&quot;alert alert-danger mt-2&quot;]</value>
      <webElementGuid>721fbbfe-991b-49a3-b717-140a42d8f487</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:idRelative</name>
      <type>Main</type>
      <value>//div[@id='rectangle_form_login']/form/div</value>
      <webElementGuid>be7146e0-2f1a-4a87-9b79-a973d7e219f5</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Chào mừng bạn trở lại'])[1]/following::div[1]</value>
      <webElementGuid>de6627cd-1af3-4779-89a2-db06783ecde0</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Đăng ký'])[1]/following::div[4]</value>
      <webElementGuid>2368849e-6628-461b-94ee-307390ba3080</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Email'])[1]/preceding::div[1]</value>
      <webElementGuid>c5fb3740-5fc7-460c-a93f-7cc54e6b4900</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Mật khẩu'])[1]/preceding::div[2]</value>
      <webElementGuid>208e172f-cab2-4c5e-b72d-e7463da204e3</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>//*/text()[normalize-space(.)='Địa chỉ email hoặc mật khẩu không đúng!']/parent::*</value>
      <webElementGuid>92f4d083-f147-45f1-9357-2b5a7358fdb9</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//form/div</value>
      <webElementGuid>b3d97790-faa1-4291-920f-d1c91bef8d59</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//div[(text() = '
                Địa chỉ email hoặc mật khẩu không đúng!
            ' or . = '
                Địa chỉ email hoặc mật khẩu không đúng!
            ')]</value>
      <webElementGuid>f221ab51-d501-4bd2-8051-84333fd87160</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
