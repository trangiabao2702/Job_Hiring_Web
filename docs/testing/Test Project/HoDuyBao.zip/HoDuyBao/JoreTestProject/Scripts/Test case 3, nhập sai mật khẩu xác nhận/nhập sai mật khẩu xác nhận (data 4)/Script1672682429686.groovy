import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('https://jore.onrender.com/candidate/home')

WebUI.click(findTestObject('UC03/Page_Jore/a_ng k'))

WebUI.setText(findTestObject('UC03/Page_Jore/input_H v tn_name'), 'Hồ Duy Bảo')

WebUI.setText(findTestObject('UC03/Page_Jore/input_Email_email'), 'hoduybaoo@gmail.com')

WebUI.setText(findTestObject('UC03/Page_Jore/input_Mt khu_password'), '1111111Ho*')

WebUI.setText(findTestObject('UC03/Page_Jore/input_Xc nhn mt khu_confirm_password_signin'), '1111111ho*')

WebUI.click(findTestObject('UC03/Page_Jore/button_ng k'))

WebUI.verifyTextPresent('Mật khẩu nhập lại không đúng !', false)

WebUI.closeBrowser()

