<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_experience</name>
   <tag></tag>
   <elementGuidId>188264e5-a9a9-409e-b638-ecfb68ea09eb</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#select_experience_candidate</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='select_experience_candidate']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>466b65fe-1249-4d95-ad55-e8308411fd1c</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>select_experience</value>
      <webElementGuid>200bb61b-aaa5-4e30-8f4f-d1c39a0a3ef1</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>select_experience_candidate</value>
      <webElementGuid>6ceb2410-d2f3-4e38-8956-8047558c3c93</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    Chưa có
    1 năm
    2 năm
    3 năm
    Hơn 3 năm
    Kinh nghiệm
  </value>
      <webElementGuid>9027adf4-5f45-4785-b5e3-ed5453c88bc3</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;select_experience_candidate&quot;)</value>
      <webElementGuid>894dd51b-c5a3-4192-9e35-74f746c8d26a</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='select_experience_candidate']</value>
      <webElementGuid>a72b4fcc-1d63-4ec9-a74e-41c90f2f672f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dành cho nhà tuyển dụng'])[1]/following::select[3]</value>
      <webElementGuid>6f32eb73-cc17-4448-87cd-00a0378d423e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Đăng ký'])[1]/following::select[3]</value>
      <webElementGuid>bb13a3ae-0263-42b7-bd81-fc6b2f2f6a0f</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tìm kiếm'])[1]/preceding::select[2]</value>
      <webElementGuid>c452543d-0494-41a9-9860-05409890427e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Top công việc được quan tâm nhất'])[1]/preceding::select[2]</value>
      <webElementGuid>0cd18b5b-f0ca-4f27-9d09-5ecb8006d366</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select[3]</value>
      <webElementGuid>e1800311-c991-4509-87a2-83db4f5246df</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'select_experience' and @id = 'select_experience_candidate' and (text() = '
    Chưa có
    1 năm
    2 năm
    3 năm
    Hơn 3 năm
    Kinh nghiệm
  ' or . = '
    Chưa có
    1 năm
    2 năm
    3 năm
    Hơn 3 năm
    Kinh nghiệm
  ')]</value>
      <webElementGuid>9fb2d4c0-b143-4895-8c18-d583b83dbf62</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
