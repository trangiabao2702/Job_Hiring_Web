<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_salary</name>
   <tag></tag>
   <elementGuidId>967fad72-10cc-4ac6-9800-679b64a03f16</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>#select_salary_candidate</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//select[@id='select_salary_candidate']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
      <webElementGuid>56049e07-30a3-429f-9f27-0398b3027cec</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>select_salary</value>
      <webElementGuid>76041904-713e-4c30-abc3-798fdec51014</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>select_salary_candidate</value>
      <webElementGuid>add332f5-c684-4bbe-b79b-c2297a7e6ff5</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    ≥ 5 triệu
    ≥ 10 triệu
    ≥ 15 triệu
    ≥ 20 triệu
    Mức lương
  </value>
      <webElementGuid>43ad7d9a-7d0b-4027-a808-6a91e4c9c999</webElementGuid>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;select_salary_candidate&quot;)</value>
      <webElementGuid>79952f27-fbfd-435c-8fb3-f6a41e770252</webElementGuid>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:attributes</name>
      <type>Main</type>
      <value>//select[@id='select_salary_candidate']</value>
      <webElementGuid>98bbcaee-b4fd-4bad-bea4-5b48028183bd</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Dành cho nhà tuyển dụng'])[1]/following::select[4]</value>
      <webElementGuid>910ac2be-0ca2-46ef-809b-52b54ed9b07d</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Đăng ký'])[1]/following::select[4]</value>
      <webElementGuid>4fc372e3-f3b9-45b8-819d-6f114fd0de1e</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Tìm kiếm'])[1]/preceding::select[1]</value>
      <webElementGuid>25061ff3-8478-4e82-bd4e-88ff7e137920</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Top công việc được quan tâm nhất'])[1]/preceding::select[1]</value>
      <webElementGuid>bc0a2325-8ae6-4051-8edc-ac11bd2937ee</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//select[4]</value>
      <webElementGuid>c230df96-5a7c-4243-8817-8cbe51e27648</webElementGuid>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:customAttributes</name>
      <type>Main</type>
      <value>//select[@name = 'select_salary' and @id = 'select_salary_candidate' and (text() = '
    ≥ 5 triệu
    ≥ 10 triệu
    ≥ 15 triệu
    ≥ 20 triệu
    Mức lương
  ' or . = '
    ≥ 5 triệu
    ≥ 10 triệu
    ≥ 15 triệu
    ≥ 20 triệu
    Mức lương
  ')]</value>
      <webElementGuid>2393eef6-4225-44dd-9ad3-df39d6f8af2f</webElementGuid>
   </webElementXpaths>
</WebElementEntity>
